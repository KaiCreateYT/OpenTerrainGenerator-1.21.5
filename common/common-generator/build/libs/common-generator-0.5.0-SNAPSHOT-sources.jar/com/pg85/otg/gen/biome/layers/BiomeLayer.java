package com.pg85.otg.gen.biome.layers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.pg85.otg.gen.biome.BiomeData;
import com.pg85.otg.gen.biome.layers.util.LayerRandomnessSource;
import com.pg85.otg.gen.biome.layers.util.LayerSampleContext;
import com.pg85.otg.interfaces.ILayerSampler;

/**
 * Places the biomes at a specific depth, given the biome groups.
 */
class BiomeLayer extends BiomeLayerBase
{
	protected final Map<BiomeGroup, Map<Integer, BiomeData>> groupBiomes = new HashMap<>();

	BiomeLayer(BiomeLayerData data, int depth)
	{
		super(data, depth);

		// Iterate through all of the groups
		for (Map.Entry<Integer, List<BiomeGroup>> entry : data.groups.entrySet())
		{
			for (BiomeGroup group : entry.getValue())
			{
				int cumulativeRarity = 0;

				Map<Integer, BiomeData> biomes = new TreeMap<>();

				for (BiomeData biome : group.biomes)
				{
					if (depth == biome.biomeSize)
					{
						cumulativeRarity += biome.rarity;
						biomes.put(cumulativeRarity, biome);
					}
				}

				if (cumulativeRarity > 0)
				{
					this.groupBiomes.put(group, biomes);
				}
			}
		}
	}

	@Override
	public int sample(LayerSampleContext<?> context, ILayerSampler parent, int x, int z)
	{
		int sample = parent.sample(x, z);

		if (
			// If biome bits have not yet been set (this column has not been cached), do so now.
			(sample & BiomeLayers.GROUP_BITS) != 0 &&
			(sample & BiomeLayers.BIOME_BITS) == 0
		)
		{
			int biomeGroupId = BiomeLayers.getGroupId(sample);
			if (biomeGroupId > 0)
			{
				BiomeGroup group = this.data.groupRegistry.get(biomeGroupId);
				if (group.maxRarityPerDepth[depth] != 0 && this.groupBiomes.containsKey(group))
				{
					BiomeData biomeData = getBiomeFromGroup(context, group.maxRarityPerDepth[depth], this.groupBiomes.get(group));
					return sample | biomeData.id;
				}
			}
		}

		return sample;
	}

	private BiomeData getBiomeFromGroup(LayerRandomnessSource random, int maxRarity, Map<Integer, BiomeData> rarityMap)
	{
		// Get a random rarity number from our max rarity
		int chosenRarity = random.nextInt(maxRarity);

		// Iterate through the rarity map and see if the chosen rarity is less than the rarity for each group, if it is then return.
		for (Map.Entry<Integer, BiomeData> entry : rarityMap.entrySet())
		{
			if (chosenRarity < entry.getKey())
			{
				return entry.getValue();
			}
		}

		// Fallback
		return this.data.oceanBiomeData;
	}
}
